clear all; clc;

load('file_index.mat');

for i = 1:size(Instron,1)
    %read tables
    opts = detectImportOptions(Instron(i),'NumHeaderLines',5);
    A = readtable(Instron(i),opts);
    B = readtable(SPuD(i));

    %convert displacement and force to arrays
    C = table2array(A(:,2:3));   
    D = table2array(B(:,1:2));

    %read in minor diameter
    minor = minor_diameter(i);

    %trim everything before halway point
    C(C(:,1)<-minor/2,:) = [];
    D(D(:,1)<-minor/2,:) = [];

    %trim everything past zero
    C(C(:,1)>0,:) = [];
    D(D(:,1)>0,:) = [];

    %calculate the IPS for Instron
    C_ips = 0;
    for j = 2:size(C,1)
        Fn = C(j,2);
        Fn1 = C(j-1,2);
        xn = C(j,1) - C(1,1);
        xn1 = C(j-1,1) - C(1,1);
        C_ips = C_ips + Fn*xn^4-Fn1*xn1^4;
    end
    C_ips = C_ips/abs(C(1,1));

    %calculate the IPS for SPuD
    D_ips = 0;
    for j = 2:size(D,1)
        Fn = D(j,2);
        Fn1 = D(j-1,2);
        xn = D(j,1) - D(1,1);
        xn1 = D(j-1,1) - D(1,1);
        D_ips = D_ips + Fn*xn^4-Fn1*xn1^4;
    end
    D_ips = D_ips/abs(C(1,1));

    %save to array
    IPS_Instron(i) = C_ips;
    IPS_SPuD(i) = D_ips;
end

%transpose the arrays
IPS_Instron = IPS_Instron';
IPS_SPuD = IPS_SPuD';