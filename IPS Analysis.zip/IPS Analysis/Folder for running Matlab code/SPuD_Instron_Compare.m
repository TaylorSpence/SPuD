clear all; clc;

load('file_index.mat');
for i = 1:size(Instron,1)
    %read tables
    opts = detectImportOptions(Instron(i),'NumHeaderLines',5);
    A = readtable(Instron(i),opts);
    B = readtable(SPuD(i));

    %convert displacement and force to arrays
    C = table2array(A(:,2:3));
    D = table2array(B(:,1:2));

    %read in minor diameter
    minor = minor_diameter(i);

    %trim everything before minor diameter
    C(C(:,1)<-minor,:) = [];
    D(D(:,1)<-minor,:) = [];

    %trim everything past zero
    C(C(:,1)>0,:) = [];
    D(D(:,1)>0,:) = [];

    %calculate areas under curve
    C_i = trapz(C(:,1),C(:,2));
    D_i = trapz(D(:,1),D(:,2));

    %calculate error as a percentage of the average area
    Area_Instron(i) = C_i;
    Area_SPuD(i) = D_i;
    error(i) = abs(C_i-D_i)/mean([C_i,D_i])*100;
    
    %save overlay table
    fig1 = figure('visible','off');
    plot(C(:,1),C(:,2));
    hold on;
    plot(D(:,1),D(:,2),'--');
    legend('Instron','SPuD');
    xlabel('Displacement (mm)');
    ylabel('Force (N)');
    saveas(fig1,strcat(Instron(i),'.bmp'))
end

%save comparison curve
fig1 = figure('visible','off');
plot(Area_SPuD,Area_Instron,'.')
xlabel('Area Under Curve, SPuD (Nmm)');
ylabel('Area Under Curve, Instron (Nmm)');
saveas(fig1,'AreaComparison.bmp');

%save error histogram
fig1 = figure('visible','off');
hist(error);
saveas(fig1,'AreaError.bmp');